document.addEventListener('DOMContentLoaded', function () {
  const divClassInput = document.getElementById('divClass');

  // Analyze container & state
  const analyzeContainer = document.getElementById('analyzeContainer');
  const runAnalysisBtn = document.getElementById('runAnalysis');
  const startFlowBtn = document.getElementById('startFlow');
  const analyzePageBtn = document.getElementById('analyzePage');
  const finishFlowBtn = document.getElementById('finishFlow');
  const flowNameField = document.getElementById('flowNameField');
  const flowNameDisplay = document.getElementById('flowName');
  const confirmFlowBtn = document.getElementById('confirmFlow');
  const statusDiv = document.getElementById('status');

  function setAnalyzeState(state) {
    analyzeContainer.dataset.state = state;
  }

  // Tab switching
  const tabs = document.querySelectorAll('.tab');
  const tabPanels = document.querySelectorAll('.tab-panel');

  function activateTab(tab) {
    tabs.forEach(function (t) {
      t.classList.remove('active');
      t.setAttribute('aria-selected', 'false');
    });
    tabPanels.forEach(function (p) {
      p.classList.remove('active');
    });
    tab.classList.add('active');
    tab.setAttribute('aria-selected', 'true');
    const panel = document.getElementById(tab.getAttribute('aria-controls'));
    if (panel) panel.classList.add('active');
    // Remember last active tab
    chrome.storage.local.set({ lastActiveTab: tab.getAttribute('aria-controls') });
  }

  tabs.forEach(function (tab) {
    tab.addEventListener('click', function () {
      activateTab(tab);
    });
  });

  // Restore last active tab
  chrome.storage.local.get(['lastActiveTab'], function (result) {
    if (result.lastActiveTab) {
      const savedTab = document.querySelector('.tab[aria-controls="' + result.lastActiveTab + '"]');
      if (savedTab) activateTab(savedTab);
    }
  });

  let isFlowActive = false;
  let currentFlowName = '';

  const checkboxes = {
    fontSize: document.getElementById('checkFontSize'),
    iconSize: document.getElementById('checkIconSize'),
    contrast: document.getElementById('checkContrast'),
    borderContrast: document.getElementById('checkBorderContrast'),
    ariaLabel: document.getElementById('checkAriaLabel'),
    emptyElements: document.getElementById('checkEmptyElements'),
    // Advanced checks
    focusVisible: document.getElementById('checkFocusVisible'),
    tabOrder: document.getElementById('checkTabOrder'),
    altText: document.getElementById('checkAltText'),
    formLabels: document.getElementById('checkFormLabels'),
    headings: document.getElementById('checkHeadings'),
    keyboardTraps: document.getElementById('checkKeyboardTraps'),
    hiddenContent: document.getElementById('checkHiddenContent'),
    colorDependence: document.getElementById('checkColorDependence'),
    language: document.getElementById('checkLanguage'),
    linkText: document.getElementById('checkLinkText'),
  };

  // Load saved state
  chrome.storage.local.get(['divClass', 'options'], function (result) {
    console.log('Loading saved state:', result);

    if (result.divClass) {
      divClassInput.value = result.divClass;
    }

    if (result.options) {
      checkboxes.fontSize.checked = result.options.fontSize !== false;
      checkboxes.iconSize.checked = result.options.iconSize !== false;
      checkboxes.contrast.checked = result.options.contrast !== false;
      checkboxes.borderContrast.checked =
        result.options.borderContrast !== false;
      checkboxes.ariaLabel.checked = result.options.ariaLabel !== false;
      checkboxes.emptyElements.checked = result.options.emptyElements === true; // Default false

      // Advanced checks - all default to false
      checkboxes.focusVisible.checked = result.options.focusVisible === true;
      checkboxes.tabOrder.checked = result.options.tabOrder === true;
      checkboxes.altText.checked = result.options.altText === true;
      checkboxes.formLabels.checked = result.options.formLabels === true;
      checkboxes.headings.checked = result.options.headings === true;
      checkboxes.keyboardTraps.checked = result.options.keyboardTraps === true;
      checkboxes.hiddenContent.checked = result.options.hiddenContent === true;
      checkboxes.colorDependence.checked =
        result.options.colorDependence === true;
      checkboxes.language.checked = result.options.language === true;
      checkboxes.linkText.checked = result.options.linkText === true;
    }
  });

  // Save state on change
  function saveState() {
    const options = getSelectedOptions();

    const dataToSave = {
      divClass: divClassInput.value,
      options: options,
    };

    chrome.storage.local.set(dataToSave, function () {
      if (chrome.runtime.lastError) {
        console.error('Error saving state:', chrome.runtime.lastError);
      } else {
        console.log('State saved:', dataToSave);
      }
    });
  }

  divClassInput.addEventListener('input', saveState);
  divClassInput.addEventListener('change', saveState); // Save on blur/change too
  Object.values(checkboxes).forEach((cb) =>
    cb.addEventListener('change', saveState)
  );

  // Save state before popup closes
  window.addEventListener('beforeunload', saveState);

  // Helper: build options object from checkboxes (avoids duplication)
  function getSelectedOptions() {
    return {
      fontSize: checkboxes.fontSize.checked,
      iconSize: checkboxes.iconSize.checked,
      contrast: checkboxes.contrast.checked,
      borderContrast: checkboxes.borderContrast.checked,
      ariaLabel: checkboxes.ariaLabel.checked,
      emptyElements: checkboxes.emptyElements.checked,
      focusVisible: checkboxes.focusVisible.checked,
      tabOrder: checkboxes.tabOrder.checked,
      altText: checkboxes.altText.checked,
      formLabels: checkboxes.formLabels.checked,
      headings: checkboxes.headings.checked,
      keyboardTraps: checkboxes.keyboardTraps.checked,
      hiddenContent: checkboxes.hiddenContent.checked,
      colorDependence: checkboxes.colorDependence.checked,
      language: checkboxes.language.checked,
      linkText: checkboxes.linkText.checked,
    };
  }

  // Shared analysis logic
  async function runAnalysis() {
    const divClass = divClassInput.value.trim();

    if (!divClass) {
      showStatus('Please enter a div class name', 'error');
      return;
    }

    const options = getSelectedOptions();

    if (!Object.values(options).some((v) => v)) {
      showStatus('Please enable at least one audit option', 'error');
      return;
    }

    // Disable whichever button triggered this
    const triggerBtn = isFlowActive ? analyzePageBtn : runAnalysisBtn;
    triggerBtn.disabled = true;
    showStatus('Running analysis...', 'info');

    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });

      // Inject scripts dynamically into the current tab
      try {
        await chrome.scripting.insertCSS({
          target: { tabId: tab.id },
          files: ['styles/content.css'],
        });
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['src/browser-polyfill.js', 'src/report.js', 'src/content.js'],
        });
      } catch (injectionError) {
        console.log('Scripts may already be injected, continuing...', injectionError);
      }

      await new Promise((resolve) => setTimeout(resolve, 100));

      chrome.storage.local.set({ analysisStatus: 'idle', analysisProgress: 0 });

      const progressInterval = setInterval(() => {
        chrome.storage.local.get(['analysisProgress', 'analysisStatus'], (data) => {
          if (data.analysisProgress) {
            showStatus(`Running analysis... ${data.analysisProgress}%`, 'info');
          }
          if (data.analysisStatus === 'completed' || data.analysisStatus === 'failed') {
            clearInterval(progressInterval);
          }
        });
      }, 500);

      const message = {
        action: 'runAudit',
        divClass: divClass,
        options: options,
      };
      if (isFlowActive && currentFlowName) {
        message.flowName = currentFlowName;
      }

      chrome.tabs.sendMessage(tab.id, message, function (response) {
        clearInterval(progressInterval);
        triggerBtn.disabled = false;

        if (chrome.runtime.lastError) {
          chrome.storage.local.get(['analysisStatus', 'auditReport'], (data) => {
            if (data.analysisStatus === 'completed' && data.auditReport) {
              showStatus('Analysis complete! Check the report.', 'success');
            } else {
              showStatus('Analysis may still be running. Please wait...', 'info');
            }
          });
          return;
        }

        if (response && response.success) {
          showStatus(`Analysis complete! Found ${response.errorCount} issue(s)`, 'success');

          if (isFlowActive && currentFlowName) {
            updateFlowPageCount();
          }
        } else if (response && response.error) {
          showStatus(response.error, 'error');
        }
      });
    } catch (error) {
      triggerBtn.disabled = false;
      showStatus('Error: ' + error.message, 'error');
    }
  }

  function updateFlowPageCount() {
    chrome.storage.local.get(['auditReport'], function (data) {
      const report = data.auditReport || {};
      const flowPages = report[currentFlowName] || {};
      const pageCount = Object.keys(flowPages).length;
      flowNameDisplay.textContent = `${currentFlowName} — ${pageCount} page(s)`;
    });
  }

  // Standalone analysis (no flow)
  runAnalysisBtn.addEventListener('click', function () {
    runAnalysis();
  });

  // Flow: analyze page
  analyzePageBtn.addEventListener('click', function () {
    runAnalysis();
  });

  function showStatus(message, type) {
    statusDiv.textContent = message;
    statusDiv.className = 'status-message ' + type;

    if (type === 'success' || type === 'error') {
      setTimeout(() => {
        statusDiv.className = 'status-message';
      }, 5000);
    }
  }

  // ===== FLOW MANAGEMENT =====

  startFlowBtn.addEventListener('click', function () {
    flowNameField.value = 'Flow ' + new Date().toLocaleString();
    setAnalyzeState('naming');
    flowNameField.focus();
    flowNameField.select();
  });

  function confirmFlowStart() {
    const flowName = flowNameField.value.trim();
    if (!flowName) {
      showStatus('Flow name cannot be empty', 'error');
      return;
    }

    currentFlowName = flowName;
    isFlowActive = true;

    const divClass = divClassInput.value.trim();
    const options = getSelectedOptions();

    chrome.storage.local.set({
      activeFlow: currentFlowName,
      isFlowActive: true,
      divClass: divClass,
      options: options,
    });

    chrome.runtime.sendMessage({
      action: 'flowStarted',
      flowName: currentFlowName,
    });

    setAnalyzeState('active');
    flowNameDisplay.textContent = `${currentFlowName} — 0 page(s)`;
    showStatus(`Flow "${currentFlowName}" started!`, 'success');
  }

  confirmFlowBtn.addEventListener('click', function () {
    confirmFlowStart();
  });

  flowNameField.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
      confirmFlowStart();
    } else if (e.key === 'Escape') {
      setAnalyzeState('idle');
    }
  });

  finishFlowBtn.addEventListener('click', function () {
    if (!isFlowActive) return;

    chrome.storage.local.get(['auditReport'], function (data) {
      const report = data.auditReport || {};
      const flowPages = report[currentFlowName] || {};
      const pageCount = Object.keys(flowPages).length;

      if (pageCount === 0) {
        if (!confirm('This flow has no pages analyzed. Finish it anyway?')) {
          return;
        }
      }

      isFlowActive = false;
      currentFlowName = '';

      chrome.storage.local.set({ activeFlow: null, isFlowActive: false });
      chrome.runtime.sendMessage({ action: 'flowFinished' });

      setAnalyzeState('idle');
      showStatus(`Flow finished with ${pageCount} page(s)`, 'success');
      setTimeout(() => loadReportSummary(), 500);
    });
  });

  // Restore flow state on popup open
  chrome.storage.local.get(['activeFlow', 'isFlowActive'], function (result) {
    if (result.isFlowActive && result.activeFlow) {
      currentFlowName = result.activeFlow;
      isFlowActive = true;
      setAnalyzeState('active');
      updateFlowPageCount();
    }
  });

  // ===== REPORT MANAGEMENT =====
  const reportSummary = document.getElementById('reportSummary');
  const reportActionsDiv = document.getElementById('reportActions');
  const reportTable = document.getElementById('reportTable');
  const reportTableBody = document.getElementById('reportTableBody');
  const downloadReportBtn = document.getElementById('downloadReport');
  const clearReportBtn = document.getElementById('clearReport');

  // Load and display report summary on popup load
  loadReportSummary();

  // Download report as CSV/Excel
  downloadReportBtn.addEventListener('click', async function () {
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });

      chrome.tabs.sendMessage(
        tab.id,
        { action: 'getReport' },
        function (report) {
          if (
            chrome.runtime.lastError ||
            !report ||
            Object.keys(report).length === 0
          ) {
            showStatus('No report data to download', 'error');
            return;
          }

          generateExcelFile(report);
          showStatus('Report downloaded successfully!', 'success');
        }
      );
    } catch (error) {
      showStatus('Error downloading report: ' + error.message, 'error');
    }
  });

  // Download HTML report with screenshots
  const downloadHtmlReportBtn = document.getElementById('downloadHtmlReport');
  downloadHtmlReportBtn.addEventListener('click', async function () {
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });

      chrome.tabs.sendMessage(
        tab.id,
        { action: 'getReport' },
        function (report) {
          if (
            chrome.runtime.lastError ||
            !report ||
            Object.keys(report).length === 0
          ) {
            showStatus('No report data to download', 'error');
            return;
          }

          generateHtmlReport(report);
          showStatus('HTML report with screenshots downloaded!', 'success');
        }
      );
    } catch (error) {
      showStatus('Error downloading HTML report: ' + error.message, 'error');
    }
  });

  // Clear report data
  clearReportBtn.addEventListener('click', function () {
    if (
      !confirm(
        'Are you sure you want to clear all report data? This cannot be undone.'
      )
    ) {
      return;
    }

    // Clear report directly from popup (no need to communicate with content script)
    chrome.storage.local.remove(['auditReport'], function () {
      loadReportSummary();
      reportTable.style.display = 'none';
      showStatus('Report data cleared', 'success');
    });
  });

  function loadReportSummary() {
    chrome.storage.local.get(['auditReport'], function (data) {
      const report = data.auditReport || {};
      const flowCount = Object.keys(report).length;

      let totalErrors = 0;
      let totalPages = 0;

      Object.values(report).forEach((flow) => {
        totalPages += Object.keys(flow).length;
        Object.values(flow).forEach((pageData) => {
          // Handle both old format (array) and new format (object with errors array)
          const errors = Array.isArray(pageData)
            ? pageData
            : pageData.errors || [];
          totalErrors += errors.length;
        });
      });

      if (flowCount === 0) {
        reportSummary.textContent = '';
        const p = document.createElement('p');
        p.className = 'summary-text';
        p.textContent = 'No errors collected yet. Run analysis to start.';
        reportSummary.appendChild(p);
        reportActionsDiv.style.display = 'none';
        reportTable.style.display = 'none';
      } else {
        reportSummary.textContent = '';
        const statsDiv = document.createElement('div');
        statsDiv.className = 'summary-stats';
        [['Flows', flowCount], ['Pages', totalPages], ['Total Errors', totalErrors]].forEach(([label, value]) => {
          const item = document.createElement('div');
          item.className = 'stat-item';
          const spanLabel = document.createElement('span');
          spanLabel.className = 'stat-label';
          spanLabel.textContent = label + ':';
          const spanValue = document.createElement('span');
          spanValue.className = 'stat-value';
          spanValue.textContent = value;
          item.appendChild(spanLabel);
          item.appendChild(spanValue);
          statsDiv.appendChild(item);
        });
        reportSummary.appendChild(statsDiv);
        // Always show details when there's data
        reportActionsDiv.style.display = 'flex';
        loadReportTable();
        reportTable.style.display = 'block';
      }
    });
  }

  function loadReportTable() {
    chrome.storage.local.get(['auditReport'], function (data) {
      const report = data.auditReport || {};

      reportTableBody.textContent = '';

      Object.entries(report).forEach(([flowName, pages]) => {
        Object.entries(pages).forEach(([pageName, pageData]) => {
          const errors = Array.isArray(pageData)
            ? pageData
            : pageData.errors || [];

          const row = document.createElement('tr');
          const tdFlow = document.createElement('td');
          tdFlow.textContent = flowName;
          const tdPage = document.createElement('td');
          tdPage.textContent = pageName;
          const tdErrors = document.createElement('td');
          tdErrors.textContent = errors.length;
          row.appendChild(tdFlow);
          row.appendChild(tdPage);
          row.appendChild(tdErrors);
          reportTableBody.appendChild(row);
        });
      });
    });
  }

  function generateExcelFile(report) {
    // Sanitize cell to prevent CSV injection
    function sanitizeCell(value) {
      const str = String(value).replace(/"/g, '""');
      if (/^[=+\-@\t\r]/.test(str)) {
        return '"\'' + str + '"';
      }
      return '"' + str + '"';
    }

    // Generate CSV content with multiple sections (one per flow)
    let csvContent = '\uFEFF'; // UTF-8 BOM for Excel compatibility

    Object.entries(report).forEach(([flowName, pages]) => {
      // Add flow header
      csvContent += `\n=== FLOW: ${flowName} ===\n`;
      csvContent +=
        'FLOW NAME,PAGE NAME,ERROR CODE,ELEMENT TYPE,ID,TRACK ID,DATA-TEST-ID,CLASS,SIZE,POSITION,TEXT CONTENT,ERROR MESSAGE,SCREENSHOT\n';

      // Sort pages by timestamp (chronological order)
      const sortedPages = Object.entries(pages).sort((a, b) => {
        const timestampA = a[1].pageTimestamp || ''; // Handle old format without pageTimestamp
        const timestampB = b[1].pageTimestamp || '';
        return timestampA.localeCompare(timestampB);
      });

      sortedPages.forEach(([pageName, pageData]) => {
        // Handle both old format (array) and new format (object with errors array)
        const errors = Array.isArray(pageData)
          ? pageData
          : pageData.errors || [];

        errors.forEach((error) => {
          // Create visual context string
          const visualContext = [
            error.size || 'N/A',
            error.position || 'N/A',
            (error.innerText || '').substring(0, 50) || '(no text)',
          ];

          // Screenshot info (base64 would be too long for CSV, so we indicate if available)
          const screenshotInfo = error.screenshot
            ? 'Screenshot available (see HTML report)'
            : 'No screenshot';

          const row = [
            flowName,
            pageName,
            error.errorCode,
            error.tagName,
            error.id,
            error.trackId,
            error.dataTestId,
            error.className || '',
            ...visualContext,
            error.message,
            screenshotInfo,
          ]
            .map((cell) => sanitizeCell(cell))
            .join(',');

          csvContent += row + '\n';
        });
      });

      csvContent += '\n'; // Empty line between flows
    });

    // Create download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);

    const timestamp = new Date()
      .toISOString()
      .replace(/[:.]/g, '-')
      .slice(0, -5);
    link.setAttribute('href', url);
    link.setAttribute('download', `accessibility-report-${timestamp}.csv`);
    link.style.visibility = 'hidden';

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  function generateHtmlReport(report) {
    // Generate HTML content with embedded screenshots
    let htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accessibility Report with Screenshots</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
        }
        h2 {
            color: #34495e;
            margin-top: 30px;
            background: #ecf0f1;
            padding: 10px;
            border-left: 4px solid #3498db;
        }
        h3 {
            color: #7f8c8d;
            margin-top: 20px;
        }
        .error-card {
            border: 1px solid #ddd;
            border-radius: 6px;
            padding: 15px;
            margin: 15px 0;
            background: #fafafa;
            display: grid;
            grid-template-columns: 250px 1fr;
            gap: 20px;
        }
        .error-screenshot {
            text-align: center;
        }
        .error-screenshot img {
            max-width: 100%;
            max-height: 200px;
            width: auto;
            height: auto;
            border: 2px solid #e74c3c;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            cursor: pointer;
            transition: transform 0.2s;
        }
        .error-screenshot img:hover {
            transform: scale(1.05);
        }
        .error-screenshot .no-image {
            width: 100%;
            height: 150px;
            background: #ecf0f1;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #7f8c8d;
            border-radius: 4px;
            font-style: italic;
        }
        .error-screenshot-hint {
            font-size: 11px;
            color: #7f8c8d;
            margin-top: 5px;
            font-style: italic;
        }
        .error-details {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .error-code {
            display: inline-block;
            background: #e74c3c;
            color: white;
            padding: 4px 12px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 12px;
            text-transform: uppercase;
        }
        .error-message {
            font-size: 16px;
            color: #2c3e50;
            font-weight: 500;
            margin: 10px 0;
        }
        .error-meta {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
            margin-top: 10px;
        }
        .meta-item {
            background: white;
            padding: 8px;
            border-radius: 4px;
            border-left: 3px solid #3498db;
        }
        .meta-label {
            font-size: 11px;
            color: #7f8c8d;
            text-transform: uppercase;
            font-weight: bold;
        }
        .meta-value {
            font-size: 13px;
            color: #2c3e50;
            font-family: 'Courier New', monospace;
        }
        .summary {
            background: #3498db;
            color: white;
            padding: 20px;
            border-radius: 6px;
            margin-bottom: 30px;
        }
        .summary-stats {
            display: flex;
            gap: 30px;
            margin-top: 15px;
        }
        .summary-stat {
            text-align: center;
        }
        .summary-stat-value {
            font-size: 32px;
            font-weight: bold;
        }
        .summary-stat-label {
            font-size: 14px;
            opacity: 0.9;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            color: #7f8c8d;
            font-size: 14px;
        }
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 10000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.9);
            animation: fadeIn 0.3s;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .modal-content {
            position: relative;
            margin: 2% auto;
            padding: 20px;
            width: 95%;
            max-width: none;
            max-height: 90vh;
            overflow: auto;
            display: flex;
            align-items: flex-start;
            justify-content: center;
        }
        .modal-content img {
            width: auto;
            height: auto;
            max-width: none;
            max-height: none;
            border-radius: 4px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.5);
            cursor: default;
        }
        .modal-close {
            position: absolute;
            top: 15px;
            right: 35px;
            color: #f1f1f1;
            font-size: 40px;
            font-weight: bold;
            cursor: pointer;
            background: rgba(0,0,0,0.5);
            width: 45px;
            height: 45px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            line-height: 1;
            transition: all 0.3s;
        }
        .modal-close:hover,
        .modal-close:focus {
            background: rgba(231, 76, 60, 0.8);
            transform: rotate(90deg);
        }
        /* Details/Summary (collapsible pages) styles */
        details {
            margin: 15px 0;
            border: 1px solid #ddd;
            border-radius: 6px;
            background: white;
            transition: all 0.3s ease;
        }
        details:hover {
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        details[open] {
            border-color: #3498db;
        }
        summary {
            cursor: pointer;
            padding: 15px;
            font-size: 16px;
            font-weight: 600;
            color: #2c3e50;
            background: #ecf0f1;
            border-radius: 6px;
            user-select: none;
            transition: all 0.2s ease;
            list-style: none;
        }
        summary::-webkit-details-marker {
            display: none;
        }
        summary:hover {
            background: #d5dbdb;
        }
        details[open] summary {
            background: #3498db;
            color: white;
            border-radius: 6px 6px 0 0;
        }
        summary::before {
            content: '▶';
            display: inline-block;
            margin-right: 8px;
            transition: transform 0.3s ease;
        }
        details[open] summary::before {
            transform: rotate(90deg);
        }
        .page-content {
            padding: 15px;
        }
        /* Nested details for (0,0) errors - Yellow theme */
        .page-content details[style*="border: 2px solid #ffc107"] {
            margin: 10px 0;
            border: 2px solid #ffc107;
            background: #fffbf0;
        }
        .page-content details[style*="border: 2px solid #ffc107"] summary {
            padding: 12px;
            font-size: 15px;
            color: #856404;
            background: #fff3cd;
            border-radius: 4px;
        }
        .page-content details[style*="border: 2px solid #ffc107"] summary::before {
            content: '►';
            color: #856404;
        }
        .page-content details[style*="border: 2px solid #ffc107"][open] summary {
            background: #ffecb3;
            color: #7d5e00;
            border-radius: 4px 4px 0 0;
        }
        .page-content details[style*="border: 2px solid #ffc107"][open] summary::before {
            color: #7d5e00;
        }
        .page-content details[style*="border: 2px solid #ffc107"]:hover {
            box-shadow: 0 2px 6px rgba(255, 193, 7, 0.3);
        }
        
        /* Nested details for negative position errors - Red theme */
        .page-content details[style*="border: 2px solid #e74c3c"] {
            margin: 10px 0;
            border: 2px solid #e74c3c;
            background: #fff5f5;
        }
        .page-content details[style*="border: 2px solid #e74c3c"] summary {
            padding: 12px;
            font-size: 15px;
            color: #c0392b;
            background: #ffe6e6;
            border-radius: 4px;
        }
        .page-content details[style*="border: 2px solid #e74c3c"] summary::before {
            content: '►';
            color: #c0392b;
        }
        .page-content details[style*="border: 2px solid #e74c3c"][open] summary {
            background: #ffcccc;
            color: #a93226;
            border-radius: 4px 4px 0 0;
        }
        .page-content details[style*="border: 2px solid #e74c3c"][open] summary::before {
            color: #a93226;
        }
        .page-content details[style*="border: 2px solid #e74c3c"]:hover {
            box-shadow: 0 2px 6px rgba(231, 76, 60, 0.3);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Accessibility Audit Report</h1>
        <p style="color: #7f8c8d;">Generated on: ${new Date().toLocaleString()} | Extension v1.8.5</p>
`;

    // Calculate summary
    let totalErrors = 0;
    let totalPages = 0;
    const flowCount = Object.keys(report).length;

    Object.values(report).forEach((flow) => {
      totalPages += Object.keys(flow).length;
      Object.values(flow).forEach((pageData) => {
        const errors = Array.isArray(pageData)
          ? pageData
          : pageData.errors || [];
        totalErrors += errors.length;
      });
    });

    htmlContent += `
        <div class="summary">
            <h2 style="margin: 0; color: white; border: none;">Summary</h2>
            <div class="summary-stats">
                <div class="summary-stat">
                    <div class="summary-stat-value">${flowCount}</div>
                    <div class="summary-stat-label">Flows</div>
                </div>
                <div class="summary-stat">
                    <div class="summary-stat-value">${totalPages}</div>
                    <div class="summary-stat-label">Pages</div>
                </div>
                <div class="summary-stat">
                    <div class="summary-stat-value">${totalErrors}</div>
                    <div class="summary-stat-label">Total Errors</div>
                </div>
            </div>
        </div>
`;

    // Helper function to render error codes and messages
    const renderErrorCodesAndMessages = (error) => {
      if (error.errorCodes && error.errorCodes.length > 1) {
        // Multiple errors on same element
        const codesHtml = error.errorCodes
          .map(
            (err) =>
              `<span class="error-code" style="margin-right: 6px;">${err.code}</span>`
          )
          .join('');

        const messagesHtml = `
          <div style="margin-bottom: 12px;">
            <strong style="color: #e74c3c; font-size: 14px;">⚠️ Multiple errors on same element (${
              error.errorCodes.length
            }):</strong>
            <ul style="margin: 8px 0; padding-left: 20px; color: #555; line-height: 1.6;">
              ${error.errorCodes
                .map(
                  (err) =>
                    `<li style="margin: 4px 0;"><strong style="color: #2c3e50;">${err.code}:</strong> ${err.message}</li>`
                )
                .join('')}
            </ul>
          </div>`;

        return { codesHtml, messagesHtml };
      } else {
        // Single error
        const code =
          error.errorCode || (error.errorCodes && error.errorCodes[0].code);
        const message =
          error.message || (error.errorCodes && error.errorCodes[0].message);
        return {
          codesHtml: `<span class="error-code">${code}</span>`,
          messagesHtml: `<div class="error-message">${message}</div>`,
        };
      }
    };

    // Add each flow
    Object.entries(report).forEach(([flowName, pages]) => {
      htmlContent += `<h2>📋 Flow: ${flowName}</h2>`;

      // Sort pages by timestamp
      const sortedPages = Object.entries(pages).sort((a, b) => {
        const timestampA = a[1].pageTimestamp || '';
        const timestampB = b[1].pageTimestamp || '';
        return timestampA.localeCompare(timestampB);
      });

      sortedPages.forEach(([pageName, pageData]) => {
        const errors = Array.isArray(pageData)
          ? pageData
          : pageData.errors || [];

        // Count errors at (0,0) and negative X positions for the summary
        const errorsAt00Count = errors.filter(
          (error) => error.position && error.position === 'x:0, y:0'
        ).length;

        // Only count as "negative position error" if X position is negative
        // (element is to the left of viewport, likely intentionally hidden)
        // Ignore negative Y positions as they're just elements above viewport due to scroll
        const negativePositionCount = errors.filter((error) => {
          if (!error.position) return false;
          const posMatch = error.position.match(/x:(-?\d+),\s*y:(-?\d+)/);
          if (posMatch) {
            const xPos = parseInt(posMatch[1]);
            // Only consider negative X as problematic (left of viewport)
            return xPos < 0;
          }
          return false;
        }).length;

        const normalErrorsCount =
          errors.length - errorsAt00Count - negativePositionCount;

        let summaryText = `(${errors.length} errors`;
        if (errorsAt00Count > 0 || negativePositionCount > 0) {
          const parts = [];
          if (errorsAt00Count > 0) parts.push(`${errorsAt00Count} at 0,0`);
          if (negativePositionCount > 0)
            parts.push(`${negativePositionCount} negative pos`);
          if (normalErrorsCount > 0) parts.push(`${normalErrorsCount} normal`);
          summaryText += `: ${parts.join(', ')}`;
        }
        summaryText += ')';

        htmlContent += `
        <details>
          <summary>
            📄 ${pageName} <span style="color: #7f8c8d; font-weight: normal;">${summaryText}</span>
          </summary>
          <div class="page-content">
        `;

        // Group errors by unique element (position + tagName + className) to avoid duplicates
        const groupedErrorsMap = new Map();
        errors.forEach((error) => {
          // Create unique key using position, tagName and className (always present)
          // Don't use HTML as it may be inconsistently captured between errors
          const key = `${error.position || 'no-pos'}_${
            error.tagName || 'unknown'
          }_${error.className || 'no-class'}`;

          if (groupedErrorsMap.has(key)) {
            // Element already exists, add this error code to the array
            const existingError = groupedErrorsMap.get(key);
            existingError.errorCodes.push({
              code: error.errorCode,
              message: error.message,
            });
            // Keep the HTML from whichever error has it (prefer non-empty)
            if (!existingError.html && error.html) {
              existingError.html = error.html;
            }
            // Keep other properties that might be missing
            if (!existingError.id && error.id) existingError.id = error.id;
            if (!existingError.trackId && error.trackId)
              existingError.trackId = error.trackId;
            if (!existingError.dataTestId && error.dataTestId)
              existingError.dataTestId = error.dataTestId;
            if (!existingError.innerText && error.innerText)
              existingError.innerText = error.innerText;
            if (!existingError.parentHTML && error.parentHTML)
              existingError.parentHTML = error.parentHTML;
          } else {
            // First time seeing this element, create new entry
            groupedErrorsMap.set(key, {
              ...error,
              errorCodes: [
                {
                  code: error.errorCode,
                  message: error.message,
                },
              ],
            });
          }
        });

        // Convert map to array of grouped errors
        const groupedErrors = Array.from(groupedErrorsMap.values());

        // Separate grouped errors into three groups: position (0,0), negative X position, and others
        const errorsAt00 = [];
        const errorsNegativePos = [];
        const normalErrors = [];

        groupedErrors.forEach((error) => {
          const isAtOrigin = error.position && error.position === 'x:0, y:0';

          // Only consider negative X positions as problematic (left of viewport)
          // Negative Y positions are normal (just elements above viewport due to scroll)
          let hasNegativeXPosition = false;
          if (error.position && !isAtOrigin) {
            const posMatch = error.position.match(/x:(-?\d+),\s*y:(-?\d+)/);
            if (posMatch) {
              const xPos = parseInt(posMatch[1]);
              // Only X < 0 is problematic
              hasNegativeXPosition = xPos < 0;
            }
          }

          if (isAtOrigin) {
            errorsAt00.push(error);
          } else if (hasNegativeXPosition) {
            errorsNegativePos.push(error);
          } else {
            normalErrors.push(error);
          }
        });

        // If there are errors at position (0,0), create a nested collapsible
        if (errorsAt00.length > 0) {
          htmlContent += `
          <details style="margin: 10px 0; border: 2px solid #ffc107; border-radius: 6px; background: #fffbf0;">
            <summary style="cursor: pointer; padding: 12px; font-size: 15px; font-weight: 600; color: #856404; background: #fff3cd; border-radius: 4px; user-select: none;">
              ⚠️ Elements at position (0,0) <span style="color: #856404; font-weight: normal;">(${errorsAt00.length} errors - likely hidden/overlapping)</span>
            </summary>
            <div style="padding: 10px;">
          `;
        }

        // Render errors at (0,0) first
        errorsAt00.forEach((error, index) => {
          const isAtOrigin = true; // We know these are at origin

          // For errors at (0,0), we don't need to check negative positions
          // as the (0,0) warning is already sufficient
          const hasNegativePosition = false;

          const { codesHtml, messagesHtml } =
            renderErrorCodesAndMessages(error);

          htmlContent += `
            <div class="error-card">
                <div class="error-screenshot">
                    ${
                      error.screenshot
                        ? `<img src="${
                            error.screenshot
                          }" alt="Element screenshot" title="Click to view full size with scroll" />
                           <div class="error-screenshot-hint">📸 Full container screenshot - Click to view complete image</div>
                           ${
                             isAtOrigin
                               ? `<div class="error-screenshot-hint" style="background: #fff3cd; border-left: 4px solid #ffc107; margin-top: 8px; padding: 8px;">
                              ⚠️ <strong>Position (0,0) detected:</strong> This element is likely hidden, overlapping, or positioned at the top-left corner of the viewport. 
                              Screenshot may show the entire viewport instead of the specific element. Check the Element HTML below for more context.
                           </div>`
                               : ''
                           }
                           ${
                             hasNegativePosition
                               ? `<div class="error-screenshot-hint" style="background: #ffe6e6; border-left: 4px solid #e74c3c; margin-top: 8px; padding: 8px;">
                              ⚠️ <strong>Negative position detected (${negativeAxis}):</strong> This element is positioned outside the visible viewport (${error.position}). 
                              It may be hidden off-screen, part of a collapsed menu, or dynamically positioned. 
                              The screenshot shows the parent container with a marker indicating where the element should be located.
                           </div>`
                               : ''
                           }
                           `
                        : `<div class="no-image">No screenshot available</div>
                           ${
                             isAtOrigin
                               ? `<div class="error-screenshot-hint" style="background: #fff3cd; border-left: 4px solid #ffc107; margin-top: 8px; padding: 8px;">
                              ⚠️ <strong>Position (0,0) detected:</strong> This element is positioned at coordinates x:0, y:0. 
                              This typically indicates a hidden element, floating panel, or absolutely positioned component. 
                              The screenshot may not be available or may not accurately represent the element's visual context. 
                              Inspect the Element HTML below to identify the component.
                           </div>`
                               : ''
                           }
                           ${
                             hasNegativePosition
                               ? `<div class="error-screenshot-hint" style="background: #ffe6e6; border-left: 4px solid #e74c3c; margin-top: 8px; padding: 8px;">
                              ⚠️ <strong>Negative position detected (${negativeAxis}):</strong> This element is positioned outside the visible viewport (${error.position}). 
                              This typically indicates:
                              <ul style="margin: 5px 0; padding-left: 20px;">
                                <li>Hidden element moved off-screen (e.g., display:none transition)</li>
                                <li>Collapsed/hidden menu or dropdown content</li>
                                <li>Element with negative margins or absolute positioning</li>
                                <li>Content in a scrollable container that's not in view</li>
                              </ul>
                              The screenshot may not be available or may show the parent container. Inspect the Element HTML below to identify the component.
                           </div>`
                               : ''
                           }`
                    }
                </div>
                <div class="error-details">
                    <div>
                        ${codesHtml}
                    </div>
                    ${messagesHtml}
                    <div class="error-meta">
                        <div class="meta-item">
                            <div class="meta-label">Element</div>
                            <div class="meta-value">&lt;${
                              error.tagName
                            }&gt;</div>
                        </div>
                        ${
                          error.id
                            ? `<div class="meta-item">
                            <div class="meta-label">ID</div>
                            <div class="meta-value">${error.id}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.trackId
                            ? `<div class="meta-item">
                            <div class="meta-label">Track ID</div>
                            <div class="meta-value">${error.trackId}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.dataTestId
                            ? `<div class="meta-item">
                            <div class="meta-label">Data-Test-ID</div>
                            <div class="meta-value">${error.dataTestId}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.className
                            ? `<div class="meta-item">
                            <div class="meta-label">Class</div>
                            <div class="meta-value">${error.className}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.size
                            ? `<div class="meta-item">
                            <div class="meta-label">Size</div>
                            <div class="meta-value">${error.size}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.position
                            ? `<div class="meta-item">
                            <div class="meta-label">Position</div>
                            <div class="meta-value">${error.position}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.innerText
                            ? `<div class="meta-item">
                            <div class="meta-label">Text Content</div>
                            <div class="meta-value">${error.innerText}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.html
                            ? `<div class="meta-item" style="grid-column: 1 / -1;">
                            <div class="meta-label">Element HTML</div>
                            <div class="meta-value" style="font-family: monospace; background: #f8f9fa; padding: 8px; border-radius: 4px; word-break: break-all; white-space: pre-wrap;">${error.html
                              .replace(/</g, '&lt;')
                              .replace(/>/g, '&gt;')}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.parentHTML
                            ? `<div class="meta-item" style="grid-column: 1 / -1;">
                            <div class="meta-label">Parent Element HTML</div>
                            <div class="meta-value" style="font-family: monospace; background: #fff3cd; padding: 8px; border-radius: 4px; word-break: break-all; white-space: pre-wrap;">${error.parentHTML
                              .replace(/</g, '&lt;')
                              .replace(/>/g, '&gt;')}</div>
                        </div>`
                            : ''
                        }
                    </div>
                </div>
            </div>
          `;
        });

        // Close the (0,0) collapsible if it was opened
        if (errorsAt00.length > 0) {
          htmlContent += `
            </div>
          </details>
          `;
        }

        // If there are errors with negative X positions, create another nested collapsible
        if (errorsNegativePos.length > 0) {
          htmlContent += `
          <details style="margin: 10px 0; border: 2px solid #e74c3c; border-radius: 6px; background: #fff5f5;">
            <summary style="cursor: pointer; padding: 12px; font-size: 15px; font-weight: 600; color: #c0392b; background: #ffe6e6; border-radius: 4px; user-select: none;">
              🚫 Elements with negative X position <span style="color: #c0392b; font-weight: normal;">(${errorsNegativePos.length} errors - hidden left of viewport)</span>
            </summary>
            <div style="padding: 10px;">
          `;
        }

        // Render errors with negative X positions
        errorsNegativePos.forEach((error, index) => {
          const isAtOrigin = false;

          // Check if element has negative X position (we know it does, X < 0)
          let hasNegativePosition = true;
          let negativeAxis = 'X axis';
          if (error.position) {
            const posMatch = error.position.match(/x:(-?\d+),\s*y:(-?\d+)/);
            if (posMatch) {
              const xPos = parseInt(posMatch[1]);
              // We only include X < 0 in this group
              negativeAxis = 'X axis';
            }
          }

          const { codesHtml, messagesHtml } =
            renderErrorCodesAndMessages(error);

          htmlContent += `
            <div class="error-card">
                <div class="error-screenshot">
                    ${
                      error.screenshot
                        ? `<img src="${
                            error.screenshot
                          }" alt="Element screenshot" title="Click to view full size with scroll" />
                           <div class="error-screenshot-hint">📸 Full container screenshot - Click to view complete image</div>
                           ${
                             hasNegativePosition
                               ? `<div class="error-screenshot-hint" style="background: #ffe6e6; border-left: 4px solid #e74c3c; margin-top: 8px; padding: 8px;">
                              ⚠️ <strong>Negative X position detected (${negativeAxis}):</strong> This element is positioned left of the viewport (${error.position}). 
                              It may be intentionally hidden off-screen, part of a collapsed menu, or using negative positioning for accessibility purposes (e.g., screen reader only content). 
                              The screenshot shows the parent container with a marker indicating where the element should be located.
                           </div>`
                               : ''
                           }
                           `
                        : `<div class="no-image">No screenshot available</div>
                           ${
                             hasNegativePosition
                               ? `<div class="error-screenshot-hint" style="background: #ffe6e6; border-left: 4px solid #e74c3c; margin-top: 8px; padding: 8px;">
                              ⚠️ <strong>Negative X position detected (${negativeAxis}):</strong> This element is positioned left of the viewport (${error.position}). 
                              This typically indicates:
                              <ul style="margin: 5px 0; padding-left: 20px;">
                                <li>Hidden element moved off-screen for accessibility (e.g., screen reader only content)</li>
                                <li>Collapsed/hidden menu or drawer content</li>
                                <li>Element with negative left positioning (position:absolute; left:-9999px)</li>
                              </ul>
                              The screenshot may not be available or may show the parent container. Inspect the Element HTML below to identify the component.
                           </div>`
                               : ''
                           }`
                    }
                </div>
                <div class="error-details">
                    <div>
                        ${codesHtml}
                    </div>
                    ${messagesHtml}
                    <div class="error-meta">
                        <div class="meta-item">
                            <div class="meta-label">Element</div>
                            <div class="meta-value">&lt;${
                              error.tagName
                            }&gt;</div>
                        </div>
                        ${
                          error.id
                            ? `<div class="meta-item">
                            <div class="meta-label">ID</div>
                            <div class="meta-value">${error.id}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.trackId
                            ? `<div class="meta-item">
                            <div class="meta-label">Track ID</div>
                            <div class="meta-value">${error.trackId}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.dataTestId
                            ? `<div class="meta-item">
                            <div class="meta-label">Data-Test-ID</div>
                            <div class="meta-value">${error.dataTestId}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.className
                            ? `<div class="meta-item">
                            <div class="meta-label">Class</div>
                            <div class="meta-value">${error.className}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.size
                            ? `<div class="meta-item">
                            <div class="meta-label">Size</div>
                            <div class="meta-value">${error.size}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.position
                            ? `<div class="meta-item">
                            <div class="meta-label">Position</div>
                            <div class="meta-value">${error.position}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.innerText
                            ? `<div class="meta-item">
                            <div class="meta-label">Text Content</div>
                            <div class="meta-value">${error.innerText}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.html
                            ? `<div class="meta-item" style="grid-column: 1 / -1;">
                            <div class="meta-label">Element HTML</div>
                            <div class="meta-value" style="font-family: monospace; background: #f8f9fa; padding: 8px; border-radius: 4px; word-break: break-all; white-space: pre-wrap;">${error.html
                              .replace(/</g, '&lt;')
                              .replace(/>/g, '&gt;')}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.parentHTML
                            ? `<div class="meta-item" style="grid-column: 1 / -1;">
                            <div class="meta-label">Parent Element HTML</div>
                            <div class="meta-value" style="font-family: monospace; background: #fff3cd; padding: 8px; border-radius: 4px; word-break: break-all; white-space: pre-wrap;">${error.parentHTML
                              .replace(/</g, '&lt;')
                              .replace(/>/g, '&gt;')}</div>
                        </div>`
                            : ''
                        }
                    </div>
                </div>
            </div>
          `;
        });

        // Close the negative positions collapsible if it was opened
        if (errorsNegativePos.length > 0) {
          htmlContent += `
            </div>
          </details>
          `;
        }

        // Now render normal errors (not at position 0,0 and no negative positions)
        normalErrors.forEach((error, index) => {
          const isAtOrigin = false; // These are NOT at origin
          // These errors already passed the filter, so they don't have negative positions
          // No need to check again, just render them

          const { codesHtml, messagesHtml } =
            renderErrorCodesAndMessages(error);

          htmlContent += `
            <div class="error-card">
                <div class="error-screenshot">
                    ${
                      error.screenshot
                        ? `<img src="${error.screenshot}" alt="Element screenshot" title="Click to view full size with scroll" />
                           <div class="error-screenshot-hint">📸 Full container screenshot - Click to view complete image</div>
                           `
                        : `<div class="no-image">No screenshot available</div>`
                    }
                </div>
                <div class="error-details">
                    <div>
                        ${codesHtml}
                    </div>
                    ${messagesHtml}
                    <div class="error-meta">
                        <div class="meta-item">
                            <div class="meta-label">Element</div>
                            <div class="meta-value">&lt;${
                              error.tagName
                            }&gt;</div>
                        </div>
                        ${
                          error.id
                            ? `<div class="meta-item">
                            <div class="meta-label">ID</div>
                            <div class="meta-value">${error.id}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.trackId
                            ? `<div class="meta-item">
                            <div class="meta-label">Track ID</div>
                            <div class="meta-value">${error.trackId}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.dataTestId
                            ? `<div class="meta-item">
                            <div class="meta-label">Data-Test-ID</div>
                            <div class="meta-value">${error.dataTestId}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.className
                            ? `<div class="meta-item">
                            <div class="meta-label">Class</div>
                            <div class="meta-value">${error.className}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.size
                            ? `<div class="meta-item">
                            <div class="meta-label">Size</div>
                            <div class="meta-value">${error.size}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.position
                            ? `<div class="meta-item">
                            <div class="meta-label">Position</div>
                            <div class="meta-value">${error.position}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.innerText
                            ? `<div class="meta-item">
                            <div class="meta-label">Text Content</div>
                            <div class="meta-value">${error.innerText}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.html
                            ? `<div class="meta-item" style="grid-column: 1 / -1;">
                            <div class="meta-label">Element HTML</div>
                            <div class="meta-value" style="font-family: monospace; background: #f8f9fa; padding: 8px; border-radius: 4px; word-break: break-all; white-space: pre-wrap;">${error.html
                              .replace(/</g, '&lt;')
                              .replace(/>/g, '&gt;')}</div>
                        </div>`
                            : ''
                        }
                        ${
                          error.parentHTML
                            ? `<div class="meta-item" style="grid-column: 1 / -1;">
                            <div class="meta-label">Parent Element HTML</div>
                            <div class="meta-value" style="font-family: monospace; background: #fff3cd; padding: 8px; border-radius: 4px; word-break: break-all; white-space: pre-wrap;">${error.parentHTML
                              .replace(/</g, '&lt;')
                              .replace(/>/g, '&gt;')}</div>
                        </div>`
                            : ''
                        }
                    </div>
                </div>
            </div>
          `;
        });

        htmlContent += `
          </div>
        </details>
        `;
      });
    });

    htmlContent += `
        <div class="footer">
            <p>by @soyJairoCosta</p>
            <p>Accessibility Checker v1.8.5</p>
        </div>
    </div>

    <!-- Image Modal -->
    <div id="imageModal" class="modal">
        <span class="modal-close" onclick="closeModal()">&times;</span>
        <div class="modal-content">
            <img id="modalImage" src="" alt="Full size screenshot">
        </div>
    </div>

    <script>
        // Open modal when clicking on screenshot
        document.addEventListener('click', function(e) {
            if (e.target.tagName === 'IMG' && e.target.closest('.error-screenshot')) {
                const modal = document.getElementById('imageModal');
                const modalImg = document.getElementById('modalImage');
                modal.style.display = 'block';
                modalImg.src = e.target.src;
            }
        });

        // Close modal function
        function closeModal() {
            document.getElementById('imageModal').style.display = 'none';
        }

        // Close modal when clicking outside the image
        document.getElementById('imageModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });

        // Close modal with ESC key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeModal();
            }
        });
    </script>
</body>
</html>
`;

    // Create download
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);

    const timestamp = new Date()
      .toISOString()
      .replace(/[:.]/g, '-')
      .slice(0, -5);
    link.setAttribute('href', url);
    link.setAttribute(
      'download',
      `accessibility-report-with-screenshots-${timestamp}.html`
    );
    link.style.visibility = 'hidden';

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // Refresh report summary after each analysis
  const originalShowStatus = showStatus;
  showStatus = function (message, type) {
    originalShowStatus(message, type);
    if (type === 'success' && message.includes('Analysis complete')) {
      setTimeout(() => loadReportSummary(), 500);
    }
  };
});
